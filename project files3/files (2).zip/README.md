# ⬡ VoteChain — Decentralized Voting DApp

A blockchain-based voting application built on Ethereum. Each wallet address can vote exactly once. Votes are permanently recorded on-chain, fully transparent, and tamper-proof.

---

## 🏗 Project Structure

```
decentralized-voting/
├── contracts/
│   └── Voting.sol          ← Solidity smart contract
├── scripts/
│   └── deploy.js           ← Hardhat deployment script
├── test/
│   └── Voting.test.js      ← Contract test suite
├── index.html              ← Frontend entry point
├── style.css               ← UI styles
├── app.js                  ← ethers.js frontend logic
├── hardhat.config.js       ← Hardhat configuration
├── package.json
└── .env.example            ← Environment variable template
```

---

## ⚡ Quick Start (Local Development)

### 1. Install Dependencies

```bash
npm install
```

### 2. Compile the Smart Contract

```bash
npm run compile
```

### 3. Run Tests

```bash
npm run test
```

### 4. Start a Local Blockchain

```bash
npm run node
# Keep this terminal running
```

### 5. Deploy to Local Network (new terminal)

```bash
npm run deploy:local
```

Copy the printed **Contract Address** from the terminal output.

### 6. Update Frontend Config

Open `app.js` and replace the `CONTRACT_ADDRESS` value:

```js
// app.js — line 8
const CONTRACT_ADDRESS = "0xYourDeployedContractAddress";
```

### 7. Open the Frontend

Simply open `index.html` in your browser. No build tool needed.

Configure MetaMask to use **Localhost 8545** and import one of the Hardhat test accounts using its private key (printed when you ran `npm run node`).

---

## 🌐 Deploying to Sepolia Testnet

### 1. Set Up Environment Variables

```bash
cp .env.example .env
```

Edit `.env` and fill in:
- `PRIVATE_KEY` — your wallet's private key
- `SEPOLIA_RPC_URL` — from [Alchemy](https://alchemy.com) or [Infura](https://infura.io)
- `ETHERSCAN_API_KEY` — optional, for contract verification

### 2. Get Sepolia ETH

Visit the [Sepolia Faucet](https://sepoliafaucet.com) to get free test ETH.

### 3. Deploy

```bash
npm run deploy:sepolia
```

### 4. Verify on Etherscan (optional)

```bash
npx hardhat verify --network sepolia YOUR_CONTRACT_ADDRESS "Your Election Title"
```

---

## 🔧 Smart Contract Overview

**`Voting.sol`** — Core contract features:

| Feature | Description |
|---|---|
| `addCandidate()` | Admin-only: register a candidate before voting starts |
| `startVoting(minutes)` | Admin-only: open voting for N minutes |
| `endVoting()` | Admin-only: close voting early |
| `vote(candidateId)` | Cast a vote (once per address) |
| `getAllCandidates()` | View all candidates and vote counts |
| `getWinner()` | View current leading candidate |
| `getRemainingTime()` | Seconds until voting closes |
| `getElectionInfo()` | Full election status summary |

**Security guarantees:**
- `hasVoted` mapping prevents double voting
- `onlyAdmin` modifier restricts privileged functions  
- `whenVotingOpen` modifier enforces time window
- Immutable blockchain storage prevents tampering

---

## 🖥 Frontend Overview

**`app.js`** key functions:

| Function | Description |
|---|---|
| `connectWallet()` | MetaMask connection via ethers.js |
| `initContract()` | Attach to deployed contract |
| `refreshContractData()` | Pull latest data from chain |
| `openVoteModal()` | Confirmation dialog before voting |
| `submitVote()` | Send transaction, wait for receipt |
| `subscribeToEvents()` | Real-time updates via contract events |

**Demo mode:** If `CONTRACT_ADDRESS` is not set, the app runs with mock data so you can preview the UI without deploying.

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Smart Contract | Solidity 0.8.19 |
| Blockchain | Ethereum (EVM) |
| Dev Framework | Hardhat |
| Frontend Library | ethers.js v6 |
| UI | HTML5 + CSS3 + Vanilla JS |
| Wallet | MetaMask |

---

## 🧪 Running Tests

```bash
npm run test          # Run all tests
npm run coverage      # Test coverage report
```

Test coverage includes:
- Contract deployment validation
- Candidate management (add, restrict during voting)
- Vote casting (success path, double-vote prevention, invalid candidate)
- Multi-voter tallying and winner detection
- Admin controls and access restriction

---

## 📚 Learning Objectives Covered

- ✅ Blockchain fundamentals (blocks, transactions, immutability)
- ✅ Writing Solidity smart contracts (structs, mappings, modifiers, events)
- ✅ Deploying contracts with Hardhat
- ✅ Interacting with blockchain using ethers.js v6
- ✅ MetaMask wallet integration
- ✅ Real-time UI updates from blockchain events
- ✅ Transaction lifecycle (submit → pending → confirmed)
- ✅ One-vote-per-address enforcement on-chain

---

## ⚠ Important Notes

- **Never commit your `.env` file or private key to Git**
- Add `.env` to your `.gitignore`
- The `PRIVATE_KEY` in `.env` is only for deployment — end users sign with MetaMask
- This contract does not implement token-gated voting or Merkle proof allowlists — it's open to any wallet

---

## 📄 License

MIT
